<div class="nav">
        <ul>
         <li><a href="/home.php">Home</a><li>
         <li><a href="/classic">Classic</a><li>
         <li><a href="/spors">Sports</a><li>
         <li><a href="/suv">SUV</a><li> 
         <li><a href="/trucks">Trucks</a><li>
         <li><a href="/used">Used</a><li>
        </ul>
</div>