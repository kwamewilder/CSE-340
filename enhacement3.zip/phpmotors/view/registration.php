<!DOCTYPE html>
<html lang = "en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
        <title>PHP Motors | Register</title>
    </head>
    <body>
        <header>
            <?php
            require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/header.php';
            ?>
        </header>
        <nav class>
            <?php
              //require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/navigation.php';
              echo $navList;
            ?>
        </nav>
        <main>
            
            <div class="login">
               
                <form action="/phpmotors/accounts/index.php" method="post" >
                        <h1> Registration</h1>
                        <p> All fields required </p>

                        <div class="field">
                            <label> First name:
                            <br>
                            <input type="text" name="firstname" id="firstname" required>
                            </label>
                        </div>   
                        

                        <div class="field">
                            <label>Last name:
                            <br>
                            <input type="text" name="lastname" id="lastname"  required>
                            <br>
                            </label>
                        </div>

                        <div class="field">
                            <label>Email address: 
                            <br>
                            <input type="email" name="email" id="email" required>
                            <br>
                            </label>
                        </div>

                        <div class="field">
                        <label>Password:
                            <br>
                            <input type="password" name="password" id="password" required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
                            <br>
                            </label>
                        </div>

                        <div>
                                         
                            <button class="field-button">Register</button>
                            <input type="hidden" name="action" value="Register">
                        </div>
                    </form>
            </div>
        </main>
        
        <footer>
            <?php
            require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/common/footer.php';
            ?>
        </footer>
    </body>
</html>