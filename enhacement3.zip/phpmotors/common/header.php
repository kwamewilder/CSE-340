
<img src="/phpmotors/images/site/logo.png" alt="logo for my site">   
    
    <?php
           echo '<a href="/phpmotors/accounts/index.php?action=login" title="Login or Register" style="color: rgb(0,0,0); background-color: rgb(255,255,255); ">My Account</a>';
    ?>